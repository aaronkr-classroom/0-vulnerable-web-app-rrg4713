

<html>
 <head>
 Register page
 </head>
 <body>
 

<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $a = htmlspecialchars(trim($_POST['username']), ENT_QUOTES, 'UTF-8');
    $b = htmlspecialchars(trim($_POST['passwd']), ENT_QUOTES, 'UTF-8');
    $c = htmlspecialchars(trim($_POST['email']), ENT_QUOTES, 'UTF-8');
    $d = htmlspecialchars(trim($_POST['gender']), ENT_QUOTES, 'UTF-8');

    $stmt = $db->prepare("INSERT INTO register (username, password, email, gender) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $a, $b, $c, $d);

    if ($stmt->execute()) {
        $safe_user = htmlspecialchars($a, ENT_QUOTES, 'UTF-8');
        echo "<h2>Successfully registered as $safe_user</h2>";
    } else {
        echo '<h2>Username is taken or registration error</h2>';
    }

    $stmt->close();
    $db->close();
}
?>

<a href="/vulnerable/index.html">Go back</a>

<script>
if(top != window) {
  top.location = window.location;
}
</script>
</body>
</html>
