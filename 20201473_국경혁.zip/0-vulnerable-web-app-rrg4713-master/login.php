

<html>
 <head>
 testpage
 </head>
 <body>
 

<?php
include("config.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $a = $_POST['username'];
    $b = $_POST['passwd'];

//get user input
    $stmt = $db->prepare("SELECT * FROM register WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $a, $b);
    $stmt->execute();
    $result = $stmt->get_result();


//fetch from database


    if($row = $result->fetch_assoc()) {
        $_SESSION['login_user'] = $row["username"];
        header("Location: /vulnerable/settings.php");
    } else {
        echo 'Not authorized';
        header("Location: /vulnerable/index.html");
    }
//close database
    $stmt->close();
    $db->close();
}
?>
<script>
if(top != window) {
  top.location = window.location
}

</script>
</body>
</html>