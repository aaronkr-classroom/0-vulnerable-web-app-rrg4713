<?php
include("config.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['login_user'])) {
    $username = $_SESSION['login_user'];
    $old_pass = $_POST['oldpasswd'];
    $new_pass = $_POST['newpasswd'];

    // 기존 비밀번호 확인
    $stmt = $db->prepare("SELECT password FROM register WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($stored_pass);
    $stmt->fetch();
    $stmt->close();

    if ($stored_pass === $old_pass) {
        $stmt = $db->prepare("UPDATE register SET password = ? WHERE username = ?");
        $stmt->bind_param("ss", $new_pass, $username);
        if ($stmt->execute()) {
            echo "Password successfully changed.";
        } else {
            echo "Error updating password.";
        }
        $stmt->close();
    } else {
        echo "Incorrect current password.";
    }

    $db->close();
} else {
    echo "Unauthorized access.";
}
?>
<html>
<body>
</br>

<script>
if(top != window) {
  top.location = window.location
}

</script>
<a href="/vulnerable/settings.php" > <h3>Go back</h3> </a>
</body>
</html>
