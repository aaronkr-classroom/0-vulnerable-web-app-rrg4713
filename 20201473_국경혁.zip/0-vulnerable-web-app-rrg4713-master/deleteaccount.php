<?php
include("config.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['login_user'])) {
    $username = $_SESSION['login_user'];
    $password = $_POST['passwd'];

    // 사용자 인증
    $stmt = $db->prepare("SELECT password FROM register WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($stored_pass);
    $stmt->fetch();
    $stmt->close();

    if ($stored_pass === $password) {
        // 계정 삭제
        $stmt = $db->prepare("DELETE FROM register WHERE username = ?");
        $stmt->bind_param("s", $username);
        if ($stmt->execute()) {
            echo "Account successfully deleted.";
            session_destroy();
        } else {
            echo "Error deleting account.";
        }
        $stmt->close();
    } else {
        echo "Invalid credentials.";
    }

    $db->close();
} else {
    echo "Unauthorized access.";
}
?>



<html>
<body>
</br>

<script>
if(top != window) {
  top.location = window.location
}

</script>
<a href="/vulnerable/settings.php" > <h3> Go back </h3> </a>
</br>
<a href="/vulnerable/index.html" > <h3>Login page </h3> </a>
</body>
</html>
