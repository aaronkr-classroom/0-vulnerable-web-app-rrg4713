<?php
$whitelist = [
    'terms' => 'terms.php',
    'privacy' => 'privacy.php',
    'faq' => 'faq.php',
];

$page = $_GET['page'] ?? 'terms';  // 기본값

if (array_key_exists($page, $whitelist)) {
    include($whitelist[$page]);
} else {
    echo "Invalid page.";
}
?>