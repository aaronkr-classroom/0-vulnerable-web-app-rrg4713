<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];

    $stmt = $db->prepare("SELECT email FROM register WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($email);
    
    if ($stmt->fetch()) {
        echo "A password reset link has been sent to your registered email.";
    } else {
        echo "User not found.";
    }

    $stmt->close();
    $db->close();
} else {
    echo "Invalid request.";
}
?>