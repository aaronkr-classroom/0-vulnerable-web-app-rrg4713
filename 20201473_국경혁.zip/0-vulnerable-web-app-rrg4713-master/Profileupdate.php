<?php
include("config.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['login_user'])) {
    $a = $_SESSION['login_user'];
    $b = $_POST['email'];
    $c = $_POST['gender'];

    // Prepared statement 사용
    $stmt = $db->prepare("UPDATE register SET email = ?, gender = ? WHERE username = ?");
    $stmt->bind_param("sss", $b, $c, $a);

    if ($stmt->execute()) {
        echo "<h3>Profile updated successfully.</h3>";
    } else {
        echo "<h3>Update failed.</h3>";
    }

    $stmt->close();
    $db->close();
} else {
    echo "<h3>Unauthorized access.</h3>";
}
?>

<html>
<body>
</br>
<script>
if(top != window) {
  top.location = window.location
}

</script>
<a href="/vulnerable/settings.php" > <h3>Go back</h3> </a>
</body>
</html>
